const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Dummy data for the dashboard
const dummyData = {
  user: {
    name: "Alex Johnson",
    email: "alex.johnson@company.com",
    referralCode: "alex2025",
    totalDonations: 1250,
    rank: 3
  },
  rewards: [
    {
      id: 1,
      name: "Coffee Voucher",
      description: "Free coffee at any partner café",
      unlocked: true,
      pointsRequired: 100
    },
    {
      id: 2,
      name: "Lunch with CEO",
      description: "Exclusive lunch meeting with the CEO",
      unlocked: false,
      pointsRequired: 500
    },
    {
      id: 3,
      name: "Company Swag",
      description: "Limited edition company merchandise",
      unlocked: true,
      pointsRequired: 200
    },
    {
      id: 4,
      name: "Remote Work Day",
      description: "One day of remote work",
      unlocked: false,
      pointsRequired: 300
    }
  ],
  leaderboard: [
    { name: "Sarah Chen", donations: 2100, rank: 1 },
    { name: "Mike Rodriguez", donations: 1800, rank: 2 },
    { name: "Alex Johnson", donations: 1250, rank: 3 },
    { name: "Emily Davis", donations: 950, rank: 4 },
    { name: "David Kim", donations: 800, rank: 5 }
  ]
};

// API Routes
app.get('/api/user', (req, res) => {
  res.json(dummyData.user);
});

app.get('/api/rewards', (req, res) => {
  res.json(dummyData.rewards);
});

app.get('/api/leaderboard', (req, res) => {
  res.json(dummyData.leaderboard);
});

app.get('/api/dashboard', (req, res) => {
  res.json({
    user: dummyData.user,
    rewards: dummyData.rewards,
    leaderboard: dummyData.leaderboard
  });
});

// Serve the main HTML file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

app.get('/leaderboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'leaderboard.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Dashboard available at http://localhost:${PORT}/dashboard`);
  console.log(`Leaderboard available at http://localhost:${PORT}/leaderboard`);
}); 