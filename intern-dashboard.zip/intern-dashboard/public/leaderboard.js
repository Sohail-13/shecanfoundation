document.addEventListener('DOMContentLoaded', function() {
    // Initialize leaderboard
    loadLeaderboardData();
    setupEventListeners();
});

async function loadLeaderboardData() {
    try {
        // Fetch leaderboard data from API
        const response = await fetch('/api/leaderboard');
        const data = await response.json();
        
        // Update leaderboard with fetched data
        updateLeaderboard(data);
        
    } catch (error) {
        console.error('Error loading leaderboard data:', error);
        // Fallback to static data if API fails
        loadStaticLeaderboardData();
    }
}

function updateLeaderboard(data) {
    populateLeaderboardTable(data);
    updatePodium(data);
}

function populateLeaderboardTable(leaderboardData) {
    const tableBody = document.getElementById('leaderboardTableBody');
    tableBody.innerHTML = '';
    
    leaderboardData.forEach((user, index) => {
        const row = document.createElement('tr');
        
        // Determine rank class for styling
        let rankClass = 'rank-other';
        if (user.rank === 1) rankClass = 'rank-1';
        else if (user.rank === 2) rankClass = 'rank-2';
        else if (user.rank === 3) rankClass = 'rank-3';
        
        // Generate random stats for demo purposes
        const referrals = Math.floor(Math.random() * 20) + 5;
        const rewards = Math.floor(Math.random() * 5) + 1;
        const status = user.rank <= 3 ? 'Top Performer' : 'Active';
        
        row.innerHTML = `
            <td>
                <div class="rank-badge ${rankClass}">${user.rank}</div>
            </td>
            <td>
                <div class="user-info">
                    <img src="https://via.placeholder.com/32x32/4F46E5/FFFFFF?text=${user.name.charAt(0)}" alt="${user.name}" class="user-avatar">
                    <span class="user-name">${user.name}</span>
                </div>
            </td>
            <td class="donations">$${user.donations.toLocaleString()}</td>
            <td>${referrals}</td>
            <td>${rewards}</td>
            <td>
                <span class="status-badge ${status.toLowerCase().replace(' ', '-')}">${status}</span>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
}

function updatePodium(leaderboardData) {
    // Update podium with top 3 users
    const top3 = leaderboardData.slice(0, 3);
    
    // Update first place
    if (top3[0]) {
        const firstPlace = document.querySelector('.podium-place.first .podium-info h3');
        const firstAmount = document.querySelector('.podium-place.first .podium-amount');
        if (firstPlace) firstPlace.textContent = top3[0].name;
        if (firstAmount) firstAmount.textContent = `$${top3[0].donations.toLocaleString()}`;
    }
    
    // Update second place
    if (top3[1]) {
        const secondPlace = document.querySelector('.podium-place.second .podium-info h3');
        const secondAmount = document.querySelector('.podium-place.second .podium-amount');
        if (secondPlace) secondPlace.textContent = top3[1].name;
        if (secondAmount) secondAmount.textContent = `$${top3[1].donations.toLocaleString()}`;
    }
    
    // Update third place
    if (top3[2]) {
        const thirdPlace = document.querySelector('.podium-place.third .podium-info h3');
        const thirdAmount = document.querySelector('.podium-place.third .podium-amount');
        if (thirdPlace) thirdPlace.textContent = top3[2].name;
        if (thirdAmount) thirdAmount.textContent = `$${top3[2].donations.toLocaleString()}`;
    }
}

function loadStaticLeaderboardData() {
    // Fallback static data
    const staticData = [
        { name: "Sarah Chen", donations: 2100, rank: 1 },
        { name: "Mike Rodriguez", donations: 1800, rank: 2 },
        { name: "Alex Johnson", donations: 1250, rank: 3 },
        { name: "Emily Davis", donations: 950, rank: 4 },
        { name: "David Kim", donations: 800, rank: 5 },
        { name: "Jessica Lee", donations: 750, rank: 6 },
        { name: "Ryan Thompson", donations: 650, rank: 7 },
        { name: "Amanda Wilson", donations: 600, rank: 8 },
        { name: "Chris Brown", donations: 550, rank: 9 },
        { name: "Lisa Garcia", donations: 500, rank: 10 }
    ];
    
    updateLeaderboard(staticData);
}

function setupEventListeners() {
    // Filter buttons functionality
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            
            // Handle filter change
            const filter = this.getAttribute('data-filter');
            handleFilterChange(filter);
        });
    });
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // Add hover effects to table rows
    const tableRows = document.querySelectorAll('.leaderboard-table tbody tr');
    tableRows.forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.backgroundColor = '#F3F4F6';
        });
        
        row.addEventListener('mouseleave', function() {
            this.style.backgroundColor = '';
        });
    });
    
    // Add click effects to podium
    const podiumPlaces = document.querySelectorAll('.podium-place');
    podiumPlaces.forEach(place => {
        place.addEventListener('click', function() {
            showUserDetails(this);
        });
    });
}

function handleFilterChange(filter) {
    // Show loading state
    showLoadingState();
    
    // Simulate API call with different data based on filter
    setTimeout(() => {
        let filteredData;
        
        switch(filter) {
            case 'month':
                filteredData = generateFilteredData(0.7); // 70% of original values
                break;
            case 'week':
                filteredData = generateFilteredData(0.3); // 30% of original values
                break;
            default:
                filteredData = generateFilteredData(1); // Full values
        }
        
        updateLeaderboard(filteredData);
        hideLoadingState();
    }, 500);
}

function generateFilteredData(multiplier) {
    const baseData = [
        { name: "Sarah Chen", donations: 2100, rank: 1 },
        { name: "Mike Rodriguez", donations: 1800, rank: 2 },
        { name: "Alex Johnson", donations: 1250, rank: 3 },
        { name: "Emily Davis", donations: 950, rank: 4 },
        { name: "David Kim", donations: 800, rank: 5 }
    ];
    
    return baseData.map(user => ({
        ...user,
        donations: Math.round(user.donations * multiplier)
    }));
}

function showUserDetails(podiumPlace) {
    const userName = podiumPlace.querySelector('h3').textContent;
    const userAmount = podiumPlace.querySelector('.podium-amount').textContent;
    const userRank = podiumPlace.querySelector('.podium-rank').textContent;
    
    showModal(`
        <div class="user-details-modal">
            <div class="user-header">
                <img src="https://via.placeholder.com/80x80/4F46E5/FFFFFF?text=${userName.charAt(0)}" alt="${userName}" class="user-avatar-large">
                <div class="user-info">
                    <h2>${userName}</h2>
                    <p class="user-rank">${userRank} Place</p>
                </div>
            </div>
            <div class="user-stats">
                <div class="stat-item">
                    <span class="stat-label">Total Donations</span>
                    <span class="stat-value">${userAmount}</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Referrals</span>
                    <span class="stat-value">${Math.floor(Math.random() * 20) + 10}</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Rewards Unlocked</span>
                    <span class="stat-value">${Math.floor(Math.random() * 5) + 2}</span>
                </div>
            </div>
            <div class="user-actions">
                <button class="btn-primary">View Profile</button>
                <button class="btn-secondary" onclick="closeModal()">Close</button>
            </div>
        </div>
    `);
}

function showLoadingState() {
    const tableBody = document.getElementById('leaderboardTableBody');
    tableBody.innerHTML = `
        <tr>
            <td colspan="6" class="loading-cell">
                <div class="loading-spinner">
                    <i class="fas fa-spinner fa-spin"></i>
                    <span>Loading leaderboard data...</span>
                </div>
            </td>
        </tr>
    `;
}

function hideLoadingState() {
    // Loading state will be replaced when data is loaded
}

function handleLogout() {
    showNotification('Logging out...', 'info');
    setTimeout(() => {
        window.location.href = '/login';
    }, 1000);
}

function showModal(content) {
    // Remove existing modal
    const existingModal = document.querySelector('.modal');
    if (existingModal) {
        existingModal.remove();
    }
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-overlay">
            <div class="modal-content">
                ${content}
            </div>
        </div>
    `;
    
    // Add modal styles
    const style = document.createElement('style');
    style.textContent = `
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1000;
            animation: fadeIn 0.3s ease;
        }
        
        .modal-overlay {
            background: rgba(0, 0, 0, 0.5);
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .modal-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            max-width: 500px;
            width: 100%;
            text-align: center;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
        }
        
        .user-details-modal .user-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
            text-align: left;
        }
        
        .user-avatar-large {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 4px solid #4F46E5;
        }
        
        .user-info h2 {
            color: #1F2937;
            margin-bottom: 5px;
        }
        
        .user-rank {
            color: #4F46E5;
            font-weight: 600;
            font-size: 1.1rem;
        }
        
        .user-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-item {
            text-align: center;
            padding: 15px;
            background: #F9FAFB;
            border-radius: 10px;
        }
        
        .stat-label {
            display: block;
            color: #6B7280;
            font-size: 12px;
            margin-bottom: 5px;
        }
        
        .stat-value {
            display: block;
            color: #1F2937;
            font-weight: 700;
            font-size: 1.2rem;
        }
        
        .user-actions {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        
        .btn-primary, .btn-secondary {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: #4F46E5;
            color: white;
        }
        
        .btn-primary:hover {
            background: #3730A3;
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background: #E5E7EB;
            color: #374151;
        }
        
        .btn-secondary:hover {
            background: #D1D5DB;
        }
        
        .loading-cell {
            text-align: center;
            padding: 40px;
        }
        
        .loading-spinner {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            color: #6B7280;
        }
        
        .loading-spinner i {
            font-size: 1.5rem;
            color: #4F46E5;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
        }
        
        .user-name {
            font-weight: 600;
            color: #1F2937;
        }
        
        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-badge.top-performer {
            background: #10B981;
            color: white;
        }
        
        .status-badge.active {
            background: #3B82F6;
            color: white;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(modal);
    
    // Close modal on overlay click
    modal.querySelector('.modal-overlay').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
}

function closeModal() {
    const modal = document.querySelector('.modal');
    if (modal) {
        modal.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

function showNotification(message, type) {
    // Remove existing notifications
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    // Style the notification
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 600;
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;
    
    // Set background color based on type
    switch(type) {
        case 'success':
            notification.style.backgroundColor = '#10B981';
            break;
        case 'error':
            notification.style.backgroundColor = '#EF4444';
            break;
        case 'info':
            notification.style.backgroundColor = '#3B82F6';
            break;
    }
    
    // Add to page
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 3000);
}

// Add CSS animations for notifications
const notificationStyle = document.createElement('style');
notificationStyle.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
    }
`;
document.head.appendChild(notificationStyle); 