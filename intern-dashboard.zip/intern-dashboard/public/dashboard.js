document.addEventListener('DOMContentLoaded', function() {
    // Initialize dashboard
    loadDashboardData();
    setupEventListeners();
    updateCurrentDate();
    
    // Update date every minute
    setInterval(updateCurrentDate, 60000);
});

async function loadDashboardData() {
    try {
        // Fetch dashboard data from API
        const response = await fetch('/api/dashboard');
        const data = await response.json();
        
        // Update dashboard with fetched data
        updateDashboard(data);
        
    } catch (error) {
        console.error('Error loading dashboard data:', error);
        // Fallback to static data if API fails
        loadStaticData();
    }
}

function updateDashboard(data) {
    // Update user information
    document.getElementById('userName').textContent = data.user.name;
    document.getElementById('userEmail').textContent = data.user.email;
    document.getElementById('totalDonations').textContent = `$${data.user.totalDonations.toLocaleString()}`;
    document.getElementById('userRank').textContent = `#${data.user.rank}`;
    document.getElementById('referralCode').textContent = data.user.referralCode;
    
    // Update rewards count
    const unlockedRewards = data.rewards.filter(reward => reward.unlocked).length;
    document.getElementById('rewardsCount').textContent = unlockedRewards;
    
    // Populate rewards grid
    populateRewards(data.rewards);
}

function populateRewards(rewards) {
    const rewardsGrid = document.getElementById('rewardsGrid');
    rewardsGrid.innerHTML = '';
    
    rewards.forEach(reward => {
        const rewardCard = document.createElement('div');
        rewardCard.className = `reward-card ${reward.unlocked ? 'unlocked' : 'locked'}`;
        
        rewardCard.innerHTML = `
            <h3>${reward.name}</h3>
            <p>${reward.description}</p>
            <span class="points">${reward.pointsRequired} points required</span>
        `;
        
        rewardsGrid.appendChild(rewardCard);
    });
}

function loadStaticData() {
    // Fallback static data
    const staticData = {
        user: {
            name: "Alex Johnson",
            email: "alex.johnson@company.com",
            referralCode: "alex2025",
            totalDonations: 1250,
            rank: 3
        },
        rewards: [
            {
                id: 1,
                name: "Coffee Voucher",
                description: "Free coffee at any partner café",
                unlocked: true,
                pointsRequired: 100
            },
            {
                id: 2,
                name: "Lunch with CEO",
                description: "Exclusive lunch meeting with the CEO",
                unlocked: false,
                pointsRequired: 500
            },
            {
                id: 3,
                name: "Company Swag",
                description: "Limited edition company merchandise",
                unlocked: true,
                pointsRequired: 200
            },
            {
                id: 4,
                name: "Remote Work Day",
                description: "One day of remote work",
                unlocked: false,
                pointsRequired: 300
            }
        ]
    };
    
    updateDashboard(staticData);
}

function setupEventListeners() {
    // Copy referral code functionality
    const copyReferralBtn = document.getElementById('copyReferralBtn');
    if (copyReferralBtn) {
        copyReferralBtn.addEventListener('click', copyReferralCode);
    }
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // Add hover effects to stat cards
    const statCards = document.querySelectorAll('.stat-card');
    statCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
    
    // Add click effects to reward cards
    const rewardCards = document.querySelectorAll('.reward-card');
    rewardCards.forEach(card => {
        card.addEventListener('click', function() {
            if (this.classList.contains('unlocked')) {
                showRewardDetails(this);
            } else {
                showLockedReward(this);
            }
        });
    });
}

function copyReferralCode() {
    const referralCode = document.getElementById('referralCode').textContent;
    
    // Use modern clipboard API if available
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(referralCode).then(() => {
            showNotification('Referral code copied to clipboard!', 'success');
        }).catch(() => {
            fallbackCopyTextToClipboard(referralCode);
        });
    } else {
        fallbackCopyTextToClipboard(referralCode);
    }
}

function fallbackCopyTextToClipboard(text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
        document.execCommand('copy');
        showNotification('Referral code copied to clipboard!', 'success');
    } catch (err) {
        showNotification('Failed to copy referral code', 'error');
    }
    
    document.body.removeChild(textArea);
}

function showRewardDetails(card) {
    const rewardName = card.querySelector('h3').textContent;
    const rewardDescription = card.querySelector('p').textContent;
    
    showModal(`
        <div class="reward-modal">
            <h2>🎉 ${rewardName}</h2>
            <p>${rewardDescription}</p>
            <div class="reward-actions">
                <button class="btn-primary">Claim Reward</button>
                <button class="btn-secondary" onclick="closeModal()">Close</button>
            </div>
        </div>
    `);
}

function showLockedReward(card) {
    const rewardName = card.querySelector('h3').textContent;
    const pointsRequired = card.querySelector('.points').textContent;
    
    showModal(`
        <div class="reward-modal">
            <h2>🔒 ${rewardName}</h2>
            <p>This reward is locked. You need ${pointsRequired} to unlock it.</p>
            <div class="progress-bar">
                <div class="progress-fill" style="width: 60%;"></div>
            </div>
            <p class="progress-text">You have 750 points (60% of required)</p>
            <div class="reward-actions">
                <button class="btn-primary">Earn More Points</button>
                <button class="btn-secondary" onclick="closeModal()">Close</button>
            </div>
        </div>
    `);
}

function showModal(content) {
    // Remove existing modal
    const existingModal = document.querySelector('.modal');
    if (existingModal) {
        existingModal.remove();
    }
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-overlay">
            <div class="modal-content">
                ${content}
            </div>
        </div>
    `;
    
    // Add modal styles
    const style = document.createElement('style');
    style.textContent = `
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1000;
            animation: fadeIn 0.3s ease;
        }
        
        .modal-overlay {
            background: rgba(0, 0, 0, 0.5);
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .modal-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            max-width: 400px;
            width: 100%;
            text-align: center;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
        }
        
        .reward-modal h2 {
            color: #1F2937;
            margin-bottom: 15px;
        }
        
        .reward-modal p {
            color: #6B7280;
            margin-bottom: 20px;
        }
        
        .progress-bar {
            background: #E5E7EB;
            height: 8px;
            border-radius: 4px;
            margin: 15px 0;
            overflow: hidden;
        }
        
        .progress-fill {
            background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%);
            height: 100%;
            transition: width 0.3s ease;
        }
        
        .progress-text {
            font-size: 14px;
            color: #6B7280;
            margin-bottom: 20px;
        }
        
        .reward-actions {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        
        .btn-primary, .btn-secondary {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: #4F46E5;
            color: white;
        }
        
        .btn-primary:hover {
            background: #3730A3;
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background: #E5E7EB;
            color: #374151;
        }
        
        .btn-secondary:hover {
            background: #D1D5DB;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(modal);
    
    // Close modal on overlay click
    modal.querySelector('.modal-overlay').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
}

function closeModal() {
    const modal = document.querySelector('.modal');
    if (modal) {
        modal.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

function handleLogout() {
    showNotification('Logging out...', 'info');
    setTimeout(() => {
        window.location.href = '/login';
    }, 1000);
}

function updateCurrentDate() {
    const dateElement = document.getElementById('currentDate');
    if (dateElement) {
        const now = new Date();
        const options = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        };
        dateElement.textContent = now.toLocaleDateString('en-US', options);
    }
}

function showNotification(message, type) {
    // Remove existing notifications
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    // Style the notification
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 600;
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;
    
    // Set background color based on type
    switch(type) {
        case 'success':
            notification.style.backgroundColor = '#10B981';
            break;
        case 'error':
            notification.style.backgroundColor = '#EF4444';
            break;
        case 'info':
            notification.style.backgroundColor = '#3B82F6';
            break;
    }
    
    // Add to page
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 3000);
}

// Add CSS animations for notifications
const notificationStyle = document.createElement('style');
notificationStyle.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
    }
`;
document.head.appendChild(notificationStyle); 